var searchData=
[
  ['hours',['hours',['../class_college.html#a8a7a762611a1d7e00c453390d49355fd',1,'College']]]
];
